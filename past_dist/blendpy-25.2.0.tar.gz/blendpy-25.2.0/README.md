# blendpy
Blendpy uses ab initio simulations with ASE calculators to compute alloy properties like enthalpy of mixing. It supports binary and ternary systems, including full and suballoys for compounds.
