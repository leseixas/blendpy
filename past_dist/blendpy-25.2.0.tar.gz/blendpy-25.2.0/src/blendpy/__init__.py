# -*- coding: utf-8 -*-
# file: __init__.py

from .blendpy import Alloy, Blendpy 
from .blendpy import version

__version__ = version
